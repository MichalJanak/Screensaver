﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;

namespace Web_Page_Screensaver
{
    static class Program
    {
        //cesta v ktere jsou ulozeny vsechny parametry screensaveru
        public static readonly string way = @".Default\Control Panel\Desktop\\screensaver";
       

        [STAThread]
        static void Main(string[] args)
        {
            // nastaveni verze zabudovaneho prohlizece 
            
            var exeName = Path.GetFileName(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", exeName, 0x2AF8, RegistryValueKind.DWord);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (args.Length > 0 && args[0].ToLower().Contains("/p"))
                return;

            if (args.Length > 0 && args[0].ToLower().Contains("/c"))
                Application.Run(new PreferencesForm());
            else
                Application.Run(new ScreensaverForm());
        }
    }
}
