﻿namespace Web_Page_Screensaver
{
    partial class PreferencesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.lbUrls = new System.Windows.Forms.ListBox();
            this.tbUrlToAdd = new System.Windows.Forms.TextBox();
            this.addUrlButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.addjmeno = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.addheslo = new System.Windows.Forms.TextBox();
            this.IntRotace = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.cbRandomize = new System.Windows.Forms.CheckBox();
            this.cbCloseOnActivity = new System.Windows.Forms.CheckBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IntRotace)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "URL adresy";
            // 
            // okButton
            // 
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okButton.Location = new System.Drawing.Point(103, 318);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 4;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(184, 318);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 5;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // lbUrls
            // 
            this.lbUrls.FormattingEnabled = true;
            this.lbUrls.Location = new System.Drawing.Point(12, 27);
            this.lbUrls.Name = "lbUrls";
            this.lbUrls.Size = new System.Drawing.Size(246, 69);
            this.lbUrls.TabIndex = 9;
            this.lbUrls.SelectedIndexChanged += new System.EventHandler(this.lbUrls_SelectedIndexChanged);
            // 
            // tbUrlToAdd
            // 
            this.tbUrlToAdd.Location = new System.Drawing.Point(12, 104);
            this.tbUrlToAdd.Name = "tbUrlToAdd";
            this.tbUrlToAdd.Size = new System.Drawing.Size(181, 20);
            this.tbUrlToAdd.TabIndex = 10;
            // 
            // addUrlButton
            // 
            this.addUrlButton.Location = new System.Drawing.Point(200, 102);
            this.addUrlButton.Name = "addUrlButton";
            this.addUrlButton.Size = new System.Drawing.Size(58, 23);
            this.addUrlButton.TabIndex = 11;
            this.addUrlButton.Text = "Přidat";
            this.addUrlButton.UseVisualStyleBackColor = true;
            this.addUrlButton.Click += new System.EventHandler(this.addUrlButton_Click);
            // 
            // panel2
            // 
            this.panel2.AccessibleName = "";
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.addjmeno);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.addheslo);
            this.panel2.Location = new System.Drawing.Point(12, 141);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(247, 86);
            this.panel2.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(10, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Přihlášení na Zabbix";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Password";
            // 
            // addjmeno
            // 
            this.addjmeno.Location = new System.Drawing.Point(74, 32);
            this.addjmeno.Name = "addjmeno";
            this.addjmeno.Size = new System.Drawing.Size(156, 20);
            this.addjmeno.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 35);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Username";
            // 
            // addheslo
            // 
            this.addheslo.Location = new System.Drawing.Point(74, 58);
            this.addheslo.Name = "addheslo";
            this.addheslo.Size = new System.Drawing.Size(156, 20);
            this.addheslo.TabIndex = 14;
            this.addheslo.UseSystemPasswordChar = true;
            // 
            // IntRotace
            // 
            this.IntRotace.Enabled = false;
            this.IntRotace.Location = new System.Drawing.Point(19, 285);
            this.IntRotace.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.IntRotace.Name = "IntRotace";
            this.IntRotace.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.IntRotace.Size = new System.Drawing.Size(40, 20);
            this.IntRotace.TabIndex = 37;
            this.IntRotace.Tag = "";
            this.IntRotace.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Enabled = false;
            this.label6.Location = new System.Drawing.Point(60, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 13);
            this.label6.TabIndex = 36;
            this.label6.Text = "sekund k přepnutí jednotlivých stránek";
            // 
            // cbRandomize
            // 
            this.cbRandomize.AutoSize = true;
            this.cbRandomize.Location = new System.Drawing.Point(19, 263);
            this.cbRandomize.Name = "cbRandomize";
            this.cbRandomize.Size = new System.Drawing.Size(189, 17);
            this.cbRandomize.TabIndex = 35;
            this.cbRandomize.Text = "Přepínání stránek v screensaveru";
            this.cbRandomize.UseVisualStyleBackColor = true;
            this.cbRandomize.CheckedChanged += new System.EventHandler(this.cbRandomize_CheckedChanged);
            // 
            // cbCloseOnActivity
            // 
            this.cbCloseOnActivity.AutoSize = true;
            this.cbCloseOnActivity.Checked = true;
            this.cbCloseOnActivity.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbCloseOnActivity.Location = new System.Drawing.Point(19, 240);
            this.cbCloseOnActivity.Name = "cbCloseOnActivity";
            this.cbCloseOnActivity.Size = new System.Drawing.Size(192, 17);
            this.cbCloseOnActivity.TabIndex = 34;
            this.cbCloseOnActivity.Text = "Přerušit screensaver pohybem myši";
            this.cbCloseOnActivity.UseVisualStyleBackColor = true;
            this.cbCloseOnActivity.CheckedChanged += new System.EventHandler(this.cbCloseOnActivity_CheckedChanged);
            // 
            // PreferencesForm
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(268, 353);
            this.Controls.Add(this.IntRotace);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.addUrlButton);
            this.Controls.Add(this.cbRandomize);
            this.Controls.Add(this.tbUrlToAdd);
            this.Controls.Add(this.cbCloseOnActivity);
            this.Controls.Add(this.lbUrls);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PreferencesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Screensaver Settings";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PreferencesForm_FormClosing);
            this.Load += new System.EventHandler(this.PreferencesForm_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IntRotace)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ListBox lbUrls;
        private System.Windows.Forms.TextBox tbUrlToAdd;
        private System.Windows.Forms.Button addUrlButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox addjmeno;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox addheslo;
        private System.Windows.Forms.NumericUpDown IntRotace;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox cbRandomize;
        private System.Windows.Forms.CheckBox cbCloseOnActivity;
    }
}