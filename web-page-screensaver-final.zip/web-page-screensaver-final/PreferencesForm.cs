﻿using System;
using System.Linq;
using Microsoft.Win32;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Web_Page_Screensaver
{
    public partial class PreferencesForm : Form
    {
        public const string URL_PREF = "Url";
        public const string CLOSE_ON_ACTIVITY_PREF = "CloseOnActivity";
        public const string INTERVAL_PREF = "RotationInterval";
        public const string RANDOMIZE_PREF = "RandomOrder";
        public const string NAME = "SCRLOG";
        public const string PASSWORD = "SCRPASS";
        public const string SCREENSAVERTIMEOUT = "ScreenSaveTimeOut";
        public const string URL_PREF_DEFAULT = "https://www.iczgroup.com/";
        public const string SCREENSAVEACTIVE = "ScreenSaveActive";
       
       
        public const string CLOSE_ON_ACTIVITY_PREF_DEFAULT = "True";
        public const string INTERVAL_PREF_DEFAULT = "30";
        public const string RANDOMIZE_PREF_DEFAULT = "False";
        //sifrovaci klic
        public const string key = "g0xko@ud";
      
       
        private ContextMenuStrip urlsContextMenu;

        public PreferencesForm()
        {
            InitializeComponent();

            urlsContextMenu = new ContextMenuStrip();
            urlsContextMenu.Opening += UrlsContextMenu_Opening;

            var moveUrlUp = urlsContextMenu.Items.Add("Posunout nahoru");
            moveUrlUp.Click += MoveUrlUp_Click;

            var moveUrlDown = urlsContextMenu.Items.Add("Posunout dolu");
            moveUrlDown.Click += MoveUrlDown_Click;

            var removeUrl = urlsContextMenu.Items.Add("Smazat URL");
            removeUrl.Click += RemoveUrl_Click;

            lbUrls.ContextMenuStrip = urlsContextMenu;
            lbUrls.MouseDown += LbUrls_MouseDown;  
        }


        private void MoveUrlDown_Click(object sender, EventArgs e)
        {
            var selected = lbUrls.SelectedItem;
            if (selected != null)
            {
                var newIndex = Math.Min(lbUrls.Items.Count - 1, lbUrls.SelectedIndex + 1);
                lbUrls.Items.RemoveAt(lbUrls.SelectedIndex);
                lbUrls.Items.Insert(newIndex, selected);
                lbUrls.SelectedIndex = newIndex;
            }
        }

        private void MoveUrlUp_Click(object sender, EventArgs e)
        {
            var selected = lbUrls.SelectedItem;
            if (selected != null)
            {
                var newIndex = Math.Max(0, lbUrls.SelectedIndex - 1);
                lbUrls.Items.RemoveAt(lbUrls.SelectedIndex);
                lbUrls.Items.Insert(newIndex, selected);
                lbUrls.SelectedIndex = newIndex;
            }
        }

        private void UrlsContextMenu_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (lbUrls.SelectedItem == null)
            {
                e.Cancel = true;
            }
        }

        private void LbUrls_MouseDown(object sender, MouseEventArgs e)
        {
            var clickedIndex = lbUrls.IndexFromPoint(e.Location);
            lbUrls.SelectedIndex = lbUrls.IndexFromPoint(e.Location);
        }

        private void RemoveUrl_Click(object sender, EventArgs e)
        {
            if (lbUrls.SelectedItem != null)
            {
                lbUrls.Items.Remove(lbUrls.SelectedItem);
               
            }
        }

        //desifrovani
        private string decrypt(string zaznam)
        {
            byte[] data = Convert.FromBase64String(zaznam);
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] keys = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(PreferencesForm.key));
                
                    using (TripleDESCryptoServiceProvider tripdes = new TripleDESCryptoServiceProvider() { Key = keys, Mode = CipherMode.ECB, Padding = PaddingMode.PKCS7 })
                    {
                        ICryptoTransform transform = tripdes.CreateDecryptor();
                        byte[] results = transform.TransformFinalBlock(data, 0, data.Length);
                        zaznam = UTF8Encoding.UTF8.GetString(results);
                    }
                
            }
            return zaznam;
        }

        //nacteni konkretni hodnoty z registru
        private string readkey(string key)
        {
            string kq = " ";
            RegistryKey sk1 = Registry.Users.CreateSubKey(@".Default\Control Panel\Desktop");
            kq = (string)sk1.GetValue(key);
         
            return kq;
        }

        private void PreferencesForm_Load(object sender, EventArgs e)
        {
            RegistryKey reg = Registry.Users.CreateSubKey(Program.way);
            loadUrls(reg);
            cbCloseOnActivity.Checked = Boolean.Parse((string)reg.GetValue(CLOSE_ON_ACTIVITY_PREF, CLOSE_ON_ACTIVITY_PREF_DEFAULT));
            IntRotace.Value = int.Parse((string)reg.GetValue(INTERVAL_PREF, INTERVAL_PREF_DEFAULT));
            cbRandomize.Checked = Boolean.Parse((string)reg.GetValue(RANDOMIZE_PREF, RANDOMIZE_PREF_DEFAULT));
          
            reg.Close();
        }

        //nacteni stranek a prihlasovacich udaju
        private void loadUrls(RegistryKey reg)
        {
            lbUrls.Items.Clear();

            var urls = ((string)reg.GetValue(URL_PREF, URL_PREF_DEFAULT)).Split(' ');
            foreach (var url in urls)
            {
                lbUrls.Items.Add(url);
            }

            string jm;
            string hl;
            if (Registry.Users.GetValue(NAME) != null) {
                 jm = readkey(NAME);
                addjmeno.Text = decrypt(jm);
            }
            else { addjmeno.Text = ""; }

            if (Registry.Users.GetValue(NAME) != null)
            {
                 hl = readkey(PASSWORD);
                addheslo.Text = decrypt(hl); 
            }
            else { addheslo.Text = ""; }              
            
        }

        protected override void OnClosed(EventArgs e)
        {
            if (DialogResult == DialogResult.OK)
            {
                RegistryKey reg = Registry.Users.CreateSubKey(Program.way);
                string cesta = Path.GetDirectoryName(Application.ExecutablePath) + @"\Web-Page-Screensaver.scr";
                writeregkey("SCRNSAVE.EXE", cesta);
                saveUrls(reg);
                reg.SetValue(CLOSE_ON_ACTIVITY_PREF, cbCloseOnActivity.Checked);
                reg.SetValue(RANDOMIZE_PREF, cbRandomize.Checked);
                reg.SetValue(INTERVAL_PREF, IntRotace.Value);

                writeregkey(SCREENSAVERTIMEOUT, INTERVAL_PREF_DEFAULT);
                writeregkey(SCREENSAVEACTIVE, "1");
                reg.Close();
            }

            base.OnClosed(e);
        }

        private void saveUrls(RegistryKey reg)
        {
            var urls = String.Join(" ", lbUrls.Items.Cast<String>());
            reg.SetValue(URL_PREF, urls);
        }

        //sifrovani
      public string encrypt (string cleartext)
        {
            byte[] data = UTF8Encoding.UTF8.GetBytes(cleartext);
          using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
          {
              byte[] keys = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
              using(TripleDESCryptoServiceProvider tripdes = new TripleDESCryptoServiceProvider() {Key = keys, Mode = CipherMode.ECB, Padding = PaddingMode.PKCS7})
              {
                  ICryptoTransform transform = tripdes.CreateEncryptor();
                  byte[] results = transform.TransformFinalBlock(data, 0, data.Length);
                  cleartext = Convert.ToBase64String(results, 0, results.Length);
                 
              }
          }
          return cleartext;
        }


        //zapsat do registru
      private void writeregkey(string keyname, object value)
      {
          RegistryKey sk1 = Registry.Users.CreateSubKey(@".Default\Control Panel\Desktop");
          sk1.SetValue(keyname, value);
      }
    

        //zaneseni hodnot pri konfiguraci screensaveru
        private void okButton_Click(object sender, EventArgs e)
        {
           string textboxjmeno = addjmeno.Text;
           string textboxheslo = addheslo.Text;
           RegistryKey reg = Registry.Users.CreateSubKey(Program.way);
                    textboxjmeno = encrypt(textboxjmeno);
                    reg.SetValue(NAME, textboxjmeno);
                    textboxheslo = encrypt(textboxheslo);
                    reg.SetValue(PASSWORD, textboxheslo);
                    reg.Close();     
            Close();
        }


        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void addUrlButton_Click(object sender, EventArgs e)
        {
            var url = tbUrlToAdd.Text;
            if (url != "") 
            { 
                lbUrls.Items.Add(url);
            }
        }


        private void lbUrls_SelectedIndexChanged(object sender, EventArgs e)
        {      }

        private void PreferencesForm_FormClosing(object sender, FormClosingEventArgs e)
        {      }


        private void cbRandomize_CheckedChanged(object sender, EventArgs e)
        {
            if (cbRandomize.Checked == true)
            {
                label6.Enabled= true;
                IntRotace.Enabled = true;
                cbCloseOnActivity.Checked = false;
            }
            else {
                label6.Enabled = false;
                IntRotace.Enabled = false;
            }
        }

        private void cbCloseOnActivity_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCloseOnActivity.Checked == true)
            {
                cbRandomize.Checked = false;
            }

        }

     
    }
}
