# web-page-screensaver

Display a web page as your screensaver

## Dependencies

[.NET Framework 4.6](https://www.microsoft.com/en-us/download/details.aspx?id=48130)

## Usage

1. Copy `Web-Page-Screensaver.scr` to your `\Windows\System32` directory
2. Choose the screen saver in the Screen Saver Settings dialog, as with any other screen saver
3. Use the `Settings...` button in the same dialog to change the web page(s) displayed by the screen saver
