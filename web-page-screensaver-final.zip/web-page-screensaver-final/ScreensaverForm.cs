﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;

namespace Web_Page_Screensaver
{
    public partial class ScreensaverForm : Form
    {
        private DateTime StartTime;
        private Timer timer;
        private int currentSiteIndex = -1;
        private GlobalUserEventHandler userEventHandler;
        private string[] urls;
        public bool hodnota;
        

        [ThreadStatic]
        private static Random random;

        public ScreensaverForm()
        {
            userEventHandler = new GlobalUserEventHandler();
            userEventHandler.Event += new GlobalUserEventHandler.UserEvent(HandleUserActivity);

            InitializeComponent();

            Cursor.Hide();
        }

        public string[] Urls
        {
            get
            {
                if (urls == null)
                {
                    RegistryKey reg = Registry.Users.CreateSubKey(Program.way);
                    urls = ((string)reg.GetValue(PreferencesForm.URL_PREF, PreferencesForm.URL_PREF_DEFAULT)).Split(' ');
                    reg.Close();
                }

                return urls;
            }
        }

        private void ScreensaverForm_Load(object sender, EventArgs e)
        {
            RegistryKey reg = Registry.Users.CreateSubKey(Program.way);
           
            //je prerusen pohybem
            if ( Boolean.Parse((string)reg.GetValue(PreferencesForm.CLOSE_ON_ACTIVITY_PREF, PreferencesForm.CLOSE_ON_ACTIVITY_PREF_DEFAULT)) == true) 
            {
                stopB.Visible = false;
                playB.Visible = false;
                nextb.Visible = false;
                closeButton.Visible = false;      
            }
            else
            {
                if (Urls.Length > 1)
                {
                    // Prehazovani URLs paklize je nastaveno
                    if (Boolean.Parse((string)reg.GetValue(PreferencesForm.RANDOMIZE_PREF, PreferencesForm.RANDOMIZE_PREF_DEFAULT)) == true)
                    {
                
                        stopB.Visible = true;
                        playB.Visible = true;
                        nextb.Visible = true;
                        closeButton.Visible = true;

                        random = new Random();

                        int n = urls.Length;
                        while (n > 1)
                        {
                            n--;
                            int k = random.Next(n + 1);
                            var value = urls[k];
                            urls[k] = urls[n];
                            urls[n] = value;
                        }
                        
                        // Nastaveni casu na prehozeni URL
                        timer = new Timer();
                        timer.Interval = int.Parse((string)reg.GetValue(PreferencesForm.INTERVAL_PREF, PreferencesForm.INTERVAL_PREF_DEFAULT)) * 1000;
                        timer.Tick += (s, ee) => RotateSite();
                        timer.Start();
                    }
                    else
                    {
                        stopB.Visible = false;
                        playB.Visible = false;
                        nextb.Visible = false;
                        closeButton.Visible = true;
                    }
                }
                else
                {
                    stopB.Visible = false;
                    playB.Visible = false;
                    nextb.Visible = false;
                    closeButton.Visible = true;
                } 

            }
            // zobrazeni prvni stranky v seznamu

            RotateSite();
            StartTime = DateTime.Now;
        }



        private void BrowseTo(string url)
        {
            // Zakazat obsluhu udalosti pri pouzivani navigace (kurzoru)
            Application.RemoveMessageFilter(userEventHandler);

            try
            {
                Debug.WriteLine("Navigating: {url}");
                webBrowser.Navigate(url);
                webBrowser.DocumentCompleted += webBrowser_DocumentCompleted;
            }
            catch
            {
                // situace kdy prohlizec objevi okno, ktere neni zavrene pred pristim volani navigace
            }

            Application.AddMessageFilter(userEventHandler);
                      
        }

        private void RotateSite()
        {
            currentSiteIndex++;

            if (currentSiteIndex >= Urls.Length)
            {
                currentSiteIndex = 0;
            }

            var url = Urls[currentSiteIndex];

            BrowseTo(url);
        }

        private string decrypt(string zaznam)
        {
            byte[] data = Convert.FromBase64String(zaznam);
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] keys = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(PreferencesForm.key));
                try
                {
                    using (TripleDESCryptoServiceProvider tripdes = new TripleDESCryptoServiceProvider() { Key = keys, Mode = CipherMode.ECB, Padding = PaddingMode.PKCS7 })
                    {
                        ICryptoTransform transform = tripdes.CreateDecryptor();
                        byte[] results = transform.TransformFinalBlock(data, 0, data.Length);
                        zaznam = UTF8Encoding.UTF8.GetString(results);
                    }
                }
                catch 
                {
                
                }
            }
            return zaznam;
        }
        
        private void HandleUserActivity()
        {
            
            if (StartTime.AddSeconds(1) > DateTime.Now) return;

            RegistryKey reg = Registry.Users.CreateSubKey(Program.way);
          
            if (Boolean.Parse((string)reg.GetValue(PreferencesForm.CLOSE_ON_ACTIVITY_PREF, PreferencesForm.CLOSE_ON_ACTIVITY_PREF_DEFAULT)))
            {
                closeButton.Visible = false;
                Close(); 
            }
            else {
                closeButton.Visible = true;
               
                Cursor.Show();
            }

            reg.Close();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }
       
        private string readkey(string key)
        {
            string kq = "";
            
            RegistryKey sk1 = Registry.Users.CreateSubKey(Program.way);
            kq = (string)sk1.GetValue(key);
            
            return kq;
        }


        private void webBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (hodnota == false)
            {
                string jmeno = readkey("SCRLOG");
                string heslo = readkey("SCRPASS");
                jmeno = decrypt(jmeno);
                heslo = decrypt(heslo);
                if (jmeno != "" & heslo != "") 
                {
                webBrowser.Document.GetElementById("name").SetAttribute("value", jmeno); 
                webBrowser.Document.GetElementById("password").SetAttribute("value", heslo);
                webBrowser.Document.GetElementById("enter").InvokeMember("Click");
                 }

                    hodnota = true;
            }
        }

        private void stopB_Click(object sender, EventArgs e)
        {
            stopB.Visible = false;
            playB.Visible = true;
            timer.Enabled = false;
        }

        private void playB_Click(object sender, EventArgs e)
        {
            stopB.Visible = true;
            playB.Visible = false;
            timer.Enabled = true;
        }

        private void nextb_Click(object sender, EventArgs e)
        {
            RotateSite();
            StartTime = DateTime.Now;
        }
       }
                
     
    public class GlobalUserEventHandler : IMessageFilter
    {
        public delegate void UserEvent();

        private const int WM_MOUSEMOVE = 0x0200;
        private const int WM_MBUTTONDBLCLK = 0x209;
        private const int WM_KEYDOWN = 0x100;
        private const int WM_KEYUP = 0x101;

        public event UserEvent Event;

        public bool PreFilterMessage(ref Message m)
        {
            if ((m.Msg >= WM_MOUSEMOVE && m.Msg <= WM_MBUTTONDBLCLK)
                || m.Msg == WM_KEYDOWN
                || m.Msg == WM_KEYUP)
            {
                if (Event != null)
                {
                    Event();
                }
            }
          
            return false;
        }
    }
}