http://opensource.org/licenses/BSD-3-Clause
